// extract here and AddObject id
let authCheck = (req,res,next) => {
    console.log("we are inside the middleware")
    r
    
}